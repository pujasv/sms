$(document).ready(function(){
	 var apath="http://localhost/sms_p/index.php/Users/";
	 $(".reg_btn").click(function(){
	 	alert(11);
	 	$.ajax({
	 		type:"post",
	 		data:$("#register_form").serialize(),
	 		url:apath+"register",
	 		success:function(res){
	 			$(".err_reg").html(res)
	 			//   console.log(response);
	 		}
	 	})
	 })

  
})