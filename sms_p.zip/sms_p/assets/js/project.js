$(document).ready(function(){
	 var apath="http://localhost/sms_p/index.php/Users/";
//	 var basepath="http://localhost/sms_p/index.php/Users/"
	 $(".reg_btn").click(function(){
	 //	alert(11);
	 	$.ajax({
	 		type:"post",
	 		data:$("#register_form").serialize(),
	 		url:apath+"register",
	 		success:function(res){
	 			$(".err_reg").html(res)
	 			//   console.log(response);
	 		}
	 	})
	 })
	 $(".log_btn").click(function(){
	 	//alert(11);
	 	$.ajax({
	 		type:"post",
	 		data:$("#login_form").serialize(),
	 		url:apath+"login_action",
	 		success:function(res){
	 	//		  alert(res);
	 			if(res == "done"){
  				window.location.href=apath;
	 			}
	 			else
	 			$(".err_log").html(res)
	 		}
	 	})
	 }) 
	 $(".change_pass").click(function(){
	 	alert(1);
	 	$.ajax({
	 		type:"post",
	 		data:$("#changepass_form").serialize(),
	 		url:apath+"changepass_action",
	 		success:function(res){
	 		// console.log(response);	
		$(".err_changepass").html(res)
	 		}
	 	})
	 }) 
})