<?php
class Users_model extends CI_Model{

	function add_user($data){
		//print_r($data) ;
	$result=$this->db->insert("sms_log",$data);
	return $result;
	}
	function user_activation_process($id)
		{
			$arr = array(
				"lstatus"=>1
			);
			$this->db->where("logid",$id);
			$this->db->update("sms_log",$arr);
			return true;
		}

}
?>