<?php
class Users_model extends CI_Model{

	function add_user($data){
		//print_r($data) ;
	$result=$this->db->insert("sms_log",$data);
	return $this->db->insert_id();
	}
	function user_activation_process($id)
		{
			$arr = array(
				"lstatus"=>1
			);
			$this->db->where("log_id",$id);
			$this->db->update("sms_log",$arr);
			return true;
		}
		function auth($email,$pass){
			// echo "$pass";
			// echo "$email";
			$result=$this->db->select('log_pass')->get_where('sms_log',array("log_email"=>$email))->result_array();
			// echo "<pre>";
			// print_r($result);
			// echo "</pre>";
			$cnt=count($result);
			if($cnt > 0){

				 $dbpass=$result[0]['log_pass'];
				 
				if($dbpass == $pass){
					return true;

				}else{
					return false;
				}
			}

		}
		function check_active($email){
			//echo "$email";
			$result=$this->db->select('lstatus')->get_where('sms_log',array("log_email"=>$email))->result_array();
				 $cnt=count($result);
			if($cnt > 0){
				  $ldbstatus=$result[0]['lstatus'];
				 
				if($ldbstatus == 1){
					return true;

				}else{
					return false;
				}
			}

		}
		function check_pass($pass,$email){
			//echo "$pass";
			//echo $email;
			$result=$this->db->select('log_pass')->get_where('sms_log',array("log_email"=>$email))->result_array();
				$cnt=count($result);
			if($cnt > 0){
//echo "</br>";
				 $dbpass=$result[0]['log_pass'];
				 
				if($dbpass == $pass){
					return true;

				}else{
					return false;
				}
			}
		}
		function update_pass($pass,$email){
			//echo "$pass";
			//echo $email;
		$arr = array(
				"log_pass"=>$pass
			);
			$this->db->where("log_email",$email);
			$this->db->update("sms_log",$arr);
			return true;	
		}
		function get_userdata($email){
			$this->db->select("log_id,log_name,log_email");
			return $this->db->get_where("sms_log",array("log_email"=>$email))->result();
		}
		function add_lab($lab_name,$user_id){
		
		$result=$this->db->select('lab_name')->get_where('library',array("user_id"=>$user_id,"lab_name"=>$lab_name ))->result_array();
		 $cnt=count($result);
		if($cnt>0){
			return false;
		}
		else{
			$arr = array(
				"user_id"=> $user_id,
				"lab_name"=>$lab_name,);	
				return $this->db->insert("library",$arr);	
			}

		
	// if($cnt > 0)
	// {
	// 	echo $dlb_name=$result[0]['lab_name'];
	// 	echo $lab_name;
	// 	if($dlb_name == $lab_name)
	// 	{
	// 		return false;
	// 	}
	// 	else{
	// 			$arr = array(
	// 			"user_id"=> $user_id,
	// 			"lab_name"=>$lab_name,);	
	// 			return $this->db->insert("library",$arr);	
	// 		}
	// }
		}

		function add_gr($gr_name,$user_id)
		{
			$result=$this->db->select('g_name')->get_where('sms_group',array("user_id"=>$user_id,"g_name"=>$gr_name ))->result_array();
		 $cnt=count($result);
		if($cnt>0){
			return false;
		}
		else{
			$arr = array(
				"user_id"=> $user_id,
				"g_name"=>$gr_name,);	
				return $this->db->insert("sms_group",$arr);	
			}
		}
}
?>