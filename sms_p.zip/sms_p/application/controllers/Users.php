<?php 
class Users extends CI_Controller{
	 Public function index()
 	{
 		//echo "string";
 		$this->load->view('index.php');
 	}
 	function login(){
 		if(!isset($_SESSION['status'])){
 		$this->load->view('login.php');
 	}
 	else
 	{
 			redirect(base_url());
 	}
 	}
 		function change_pass(){
 		if(isset($_SESSION['status'])){
 		$this->load->view('change_password.php');
 	}
 	else
 	{
 			redirect(base_url());
 	}
 	}
 	public function logout()
	{
		$this->session->unset_userdata('status');
		$this->session->sess_destroy();
		redirect(base_url());
	}
 	function register(){
 		// 	echo "<pre>";
			// print_r($_POST);
			// 	echo "</pre>";
/***********************validation***************************/			
			$this->form_validation->set_rules('log_name','Name:','trim|required|alpha_numeric_spaces|min_length[2]|max_length[50]');
			$this->form_validation->set_rules('log_email','EmailID:','trim|required|valid_email|is_unique[sms_log.log_email]');
			$this->form_validation->set_rules('log_mobile','Mobile Number:','trim|required|integer|exact_length[10]');
			$this->form_validation->set_rules('log_pass','Password:','trim|required|alpha_dash|min_length[4]|max_length[12]');
			$this->form_validation->set_rules('log_cpass','Confirm Password:','trim|required|alpha_dash|min_length[4]|max_length[12]|matches[log_pass]');
			if($this->form_validation->run()== false){
				echo validation_errors();
			}
			/***********************validation***************************/	
			else
			{
				unset($_POST['log_cpass']);
				unset($_POST['captcha']);
				$_POST['log_pass']=do_hash(	$_POST['log_pass']);
				 $this->load->model('Users_model');
          	$lastid=$this->Users_model->add_user($_POST);
          //	echo "$lastid";
            if($lastid){
              //  echo "done";
                	/***** EMAIL ********/
            	$email = $this->input->post('log_email');
            	$url = base_url()."index.php/Users/activate_user/$lastid";
            	$msg = "<a href='$url'>Activation Link</a>";
            	$this->email->set_mailtype("html");
            	$this->email->from('vishal@php-training.in', 'VISHAL');
				$this->email->to($email);
				$this->email->subject('Registration Activation Link');
				$this->email->message($msg);
				$res = $this->email->send();
				// var_dump($res);
				/**************Email***************/
            	echo "Registration Done";

            	/*************sms********************/

            	$mobile = $this->input->post('log_mobile');
            	$msgSMS = "Welcome To Sms Registration Portal";
            	$url_for_SMS = "http://api.msg91.com/api/sendhttp.php?country=91&sender=MSGIND&route=4&mobiles=91$mobile&authkey=199798A6UdpTKLV5a927baf&encrypt=&message=$msgSMS"; 
            	$res = file($url_for_SMS);
            	//print_r($res);
            	/*************sms********************/
            }
			//echo "ok";	
			}

 	}


 	public function activate_user($id)
	{
		// echo $id;
		$this->load->model('Users_model');
		$ans = $this->Users_model->user_activation_process($id);
		if($ans){
			redirect(base_url().'index.php/users/login');
		}
	}
		function login_action(){
			// echo "<pre>";
			// print_r($_POST);
			// echo "</pre>";
			/////*validation**************/

			$this->form_validation->set_rules('log_email','Email','required|trim|valid_email');
			$this->form_validation->set_rules('log_pass','Password','required|trim|alpha_dash|min_length[3]');
			if($this->form_validation->run()==false){
				echo validation_errors();
			}
			else{

				  $email=$_POST['log_email'];
				$pass=do_hash($_POST['log_pass']);
				 $this->load->model('Users_model');
				$active_ans=$this->Users_model->check_active($email);

				if(!$active_ans){
					echo "Please active user by email ";

				}
				else{
				$anth_ans=$this->Users_model->auth($email,$pass);
				if($anth_ans){
					$this->session->set_userdata('status',true);
						$this->session->set_userdata('email',$email);
						$details = $this->Users_model->get_userdata($_POST['log_email']);
						$this->session->set_userdata('log_id',$details[0]->log_id);
						$this->session->set_userdata('log_name',$details[0]->log_name);
						$this->session->set_userdata('log_email',$details[0]->log_email);
					echo "done";
			}
			else{
				echo "Invalid Emailid or Password";
			}
			}

		}
		}
		function changepass_action(){

		
			$this->form_validation->set_rules('log_cpass','Old Password:','required|trim');
			$this->form_validation->set_rules('log_npass','New Password:','required|trim');
			$this->form_validation->set_rules('log_cnpass','Confirm Password','required|trim|matches[log_npass]');
			// echo "<pre>";
			// print_r($_POST);
			// echo "</pre>";
			if($this->form_validation->run()== false){
				echo validation_errors();
			}
			else{
				if($_POST['log_cpass']==$_POST['log_npass']){
				echo "New pass & Current password is same";
				}
			else{
			// 		echo "<pre>";
			// print_r($_POST);
			// echo "</pre>";
				 $pass=do_hash($_POST['log_cpass']);
				//echo "</br>";
				//exit;
				$email=$this->session->userdata('email');
				$this->load->model('Users_model');
				$ans=$this->Users_model->check_pass($pass,$email);
				//echo "ok";
				if($ans){
					//echo "ok";
					$npass=do_hash($_POST['log_npass']);
					$this->load->model('Users_model');
					$result=$this->Users_model->update_pass($npass,$email);
					if($result){
						echo "Password Updated";
					}
				}
				else{
					echo "Current Password Mismatch";
				}
				}		
			}
		}
		function library(){
			$this->load->view('library.php');
		}
		function add_library(){
			// echo "<pre>";
			// print_r($_POST);
			// echo "</pre>";
					$user_id=$this->session->userdata('log_id');
			 $this->load->model('Users_model');
			$ans=$this->Users_model->add_lab($_POST,$user_id);
		}
}

 ?>