<?php 
class Users extends CI_Controller{
	 Public function index()
 	{
 		//echo "string";
 		$this->load->view('index.php');
 	}
 	function login(){
 		$this->load->view('login.php');
 	}
 	function register(){
 		// 	echo "<pre>";
			// print_r($_POST);
			// 	echo "</pre>";
			
			$this->form_validation->set_rules('log_name','Name:','trim|required|alpha_numeric_spaces|min_length[2]|max_length[50]');
			$this->form_validation->set_rules('log_email','EmailID:','trim|required|valid_email|is_unique[sms_log.log_email]');
			$this->form_validation->set_rules('log_mobile','Mobile Number:','trim|required|integer|exact_length[10]');
			$this->form_validation->set_rules('log_pass','Password:','trim|required|alpha_dash|min_length[4]|max_length[12]');
			$this->form_validation->set_rules('log_cpass','Confirm Password:','trim|required|alpha_dash|min_length[4]|max_length[12]|matches[log_pass]');
			if($this->form_validation->run()== false){
				echo validation_errors();
			}
			else
			{
				unset($_POST['log_cpass']);
				unset($_POST['captcha']);
				$_POST['log_pass']=do_hash(	$_POST['log_pass']);
				 $this->load->model('Users_model');
          	$lastid=$this->Users_model->add_user($_POST);
            if($lastid){
                echo "done";
                	/***** EMAIL ********/
            	$email = $this->input->post('log_email');
            	$url = base_url()."index.php/Users/activate_user/$lastid";
            	$msg = "<a href='$url'>Activation Link</a>";
            	$this->email->set_mailtype("html");
            	$this->email->from('vishal@php-training.in', 'VISHAL');
				$this->email->to($email);
				$this->email->subject('Registration Activation Link');
				$this->email->message($msg);

				$res = $this->email->send();
				// var_dump($res);
            	echo "USER ADDED";
            }
			//echo "ok";	
			}

 	}
 	public function activate_user($id)
	{
		// echo "From Mail";
		// echo $id;

			 $this->load->model('Users_model');
		$ans = $this->Users_model->user_activation_process($id);
		if($ans){
			redirect(base_url().'index.php/users/login');
		}
	}
}

 ?>