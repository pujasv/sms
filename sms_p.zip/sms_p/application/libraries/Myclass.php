<?php
class Myclass{
	public $CI="";
	function __construct(){
		$this->CI= & get_instance();
	}
	function get_lab(){
		return $this->CI->db->get('library')->result_array();
	}
		function get_grp(){
		return $this->CI->db->get('sms_group')->result_array();
	}
}
?>