<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>SMS FREE</title>
	
</head>
<body>
	<header>
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 pull-right">
					<div class="pull-right">
						<?php
							if(!isset($_SESSION['status'])):
						?>
						<ul class="login-menu login-top-padd">
							<li><a href="<?php echo base_url('index.php/users/login')?>"><i class="glyphicon glyphicon-user"></i> Login / Register</a></li>
						</ul>
						<?php
							endif;
						?>
						
						<?php
							if(isset($_SESSION['status'])):
						?>
						<ul class="login-menu login-top-padd">
							<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="glyphicon glyphicon-user"></i> Welcome <?php echo $_SESSION['email'];?> <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<li><a href="<?php echo base_url('index.php/users/change_pass')?>">Change Password</a></li>
									<li><a href="<?php echo base_url('index.php/users/logout')?>">Logout</a></li>
								</ul>							
							</li>
							
						</ul>
						<?php
							endif;
				?>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
					<figure class="logo">
						<a href="index.php"><img src="http://localhost/sms_p/assets/images/logo.png" alt="SMS Free" class="img-responsive"></a>
					</figure>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<ul class="flexy-menu main-menu">
						<li ><a href="index.php">Home</a></li>
						<li ><a href="about-us.php">About Us</a></li>
						<li>><a href="contact-us.php">Contact Us</a></li>
					</ul>
				</div>
			</div>			
		</div>
	</header>
	<?php
//		if(isset($_SESSION['for_name'])):
	?>
	<div class="menu-block">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<ul class="flexy-menu orange">						
						<li ><a href="<?php echo base_url('index.php/users/library')?>">Library / Group</a></li>
						<li ><a href="<?php echo base_url('index.php/users/create_message')?>">Create Message</a></li>
						<li><a href="<?php echo base_url('index.php/users/add_cntct') ?>">Add Contact</a></li>
						<li><a href="<?php echo base_url('index.php/users/send_sms') ?>">Send SMS</a></li>
						<li ><a href="<?php echo base_url('index.php/users/group_sms') ?>">Group SMS</a></li>
						<li ><a href="sent-sms.php">Sent SMS</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<?php
	//	endif;
	?>
	<link rel="icon" href="images/favicon.png">
<link rel="stylesheet" href="<?php echo base_url().'assets/'?>css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url().'assets/'?>css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url().'assets/'?>css/flexy-menu.css">
<link rel="stylesheet" href="<?php echo base_url().'assets/'?>css/style.css">