<?php
class Myclass{
	public $CI="";
	function __construct(){
		$this->CI= & get_instance();
	}
	function get_lab(){
			 $user_id=$this->CI->session->userdata('log_id');
			
			  $ans= $this->CI->db->select('lab_id,lab_name,user_id')->get_where('library', array('user_id' => $user_id))->result_array();
			//  print_r($ans);
//			  exit;
			  return $ans;
		//return $this->CI->db->get('library')->result_array();
	}
		function get_grp(){
				 $user_id=$this->CI->session->userdata('log_id');
			
			  $ans= $this->CI->db->select('g_id,g_name,user_id')->get_where('sms_group', array('user_id' => $user_id))->result_array();
			  	  return $ans;
		//return $this->CI->db->get('sms_group')->result_array();
	}
			function get_cnt(){
				 $user_id=$this->CI->session->userdata('log_id');
			 $ans= $this->CI->db->get('sms_per_contact')->result_array();
			 // $ans= $this->CI->db->select('per_id,per_name,per_mobile,per_gid')->get_where('sms_group', array('user_id' => $user_id))->result_array();
			  	  return $ans;
		//return $this->CI->db->get('sms_group')->result_array();
	}

}
?>